const score = document.querySelector(".score span");
const highestScore = document.querySelector(".highestScore span");
const countdownE1 = document.querySelector(".countDown");

const holes = document.querySelectorAll(".hole");
const playBtn = document.querySelector(".buttons .play");
const stopBtn = document.querySelector(".buttons .stop");
const cursor = document.querySelector(".cursor img");

window.addEventListener("mousemove", (e) => {
  cursor.style.top = e.pageY + "px";
  cursor.style.left = e.pageX + "px";

  window.addEventListener("click", () => {
    cursor.style.animation = "hit 0.1s ease";
    setTimeout(() => {
      cursor.style.removeProperty("animation");
    }, 100);
  });
});

playBtn.addEventListener("click", () => {
  playBtn.style.display = "none";
  stopBtn.style.display = "inline-block";
 
  document.querySelector(".star").innerHTML = ``
  document.querySelector(".line>span").innerHTML= `5 stars!`
  let hole;
  let points = 0;
  let highestscore=0;
 

  const startGame = setInterval(() => {
    let arrayNo = Math.floor(Math.random() * 9);
    hole = holes[arrayNo];

    let image = document.createElement("img");
    image.setAttribute("src", "mole.png");
    image.setAttribute("class", "mole");
    hole.appendChild(image);

    setTimeout(() => {
      hole.removeChild(image);
    }, 600);
  }, 700);

  window.addEventListener("click", (e) => {
    if (e.target === hole) score.innerText = ++points;
  });


  const startingMin = 0.5;
  let time = startingMin*60;
  setInterval(updateCountdown, 1000)

  function updateCountdown(){
    const minutes = Math.trunc(time/60);
    let seconds = time%60;

    
    countdownE1.innerHTML = `${minutes}:${seconds}`
  
    if (time>=1){
      time--;
    }
    if (time==1){
      clearInterval(startGame);
      stopBtn.style.display = "none";
      playBtn.style.display = "inline-block";
      if(highestscore<=points){
      highestScore.textContent=Number(score.innerText);
      }
      score.innerText = 0;
      Number(highestScore.textContent)
      if(points>=0){
        document.querySelector(".star").innerHTML = `<img src="one.png" alt=""></img>`
      if(points>=5){
          document.querySelector(".star").innerHTML = `<img src="two.png" alt=""></img>`
      }
      if(points>=10){
          document.querySelector(".star").innerHTML = `<img src="three.png" alt=""></img>`
      }
      if(points>=15){
          document.querySelector(".star").innerHTML = `<img src="four.png" alt=""></img>`
      }
      }
      if (points>=20){
        document.querySelector(".star").innerHTML = `<img src="five.png" alt=""></img>` 
      };      
    }
  }
});

document.querySelector(".line>span").addEventListener("click", display);
function display(){
  document.querySelector(".line>span").innerHTML = `<p>5 star for points 20 and above <br>4 star for points 15 and above <br>3 star for points 10 and above <br>2 star for points 5 and above <br> 1 star for points 0 and above <br><p style="font-size:20px;color:#078af6;">click on the play button to start<p></p>`
}








